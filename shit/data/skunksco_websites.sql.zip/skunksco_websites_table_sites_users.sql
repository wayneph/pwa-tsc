
-- --------------------------------------------------------

--
-- Table structure for table `sites_users`
--

CREATE TABLE `sites_users` (
  `id` int(11) NOT NULL,
  `site_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `user_slug` varchar(16) NOT NULL,
  `site_slig` varchar(16) NOT NULL,
  `status` tinyint(4) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sites_users`
--

INSERT INTO `sites_users` (`id`, `site_id`, `user_id`, `user_slug`, `site_slig`, `status`, `created`, `updated`) VALUES
(1, 1, 2, 'waynep', 'teamc', 1, '2021-02-04 11:47:04', '2021-09-13 10:27:48'),
(8, 3, 2, 'waynep', 'HamishJohnPhilip', 1, '2021-07-27 18:14:17', '2021-09-13 10:26:46'),
(3, 3, 333, 'hanishj', 'HamishJohnPhilip', 1, '2021-02-04 19:40:30', '2021-09-13 10:26:46'),
(4, 4, 365, 'christianp', 'ChristianPeterPh', 1, '2021-02-20 16:47:49', '2021-09-13 10:27:26'),
(5, 4, 2, 'waynep', 'm4u', 1, '2021-02-22 14:50:46', '2021-09-13 10:28:08'),
(6, 6, 2, 'waynep', 'apidocs', 1, '2021-02-26 13:43:39', '2021-09-13 10:28:42'),
(9, 7, 2, 'waynep', 'k8sskunks', 1, '2021-09-10 11:26:45', '2021-09-13 10:29:00'),
(10, 8, 2, '', '', 1, '2021-10-17 10:36:06', '2021-10-17 10:36:06');
