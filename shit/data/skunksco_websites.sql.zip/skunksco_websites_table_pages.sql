
-- --------------------------------------------------------

--
-- Table structure for table `pages`
--

CREATE TABLE `pages` (
  `id` int(11) NOT NULL,
  `site_id` int(11) NOT NULL,
  `uuid` varchar(64) NOT NULL,
  `slug` varchar(20) NOT NULL,
  `page_name` varchar(50) NOT NULL,
  `logo_txt` varchar(255) NOT NULL,
  `seq` int(11) NOT NULL,
  `session_resets` varchar(255) NOT NULL,
  `title` varchar(30) NOT NULL,
  `hddr_template` varchar(20) NOT NULL,
  `body_template` varchar(20) NOT NULL,
  `footer_template` varchar(20) NOT NULL,
  `style` varchar(20) NOT NULL,
  `styles_added` text NOT NULL,
  `status` tinyint(4) NOT NULL,
  `updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pages`
--

INSERT INTO `pages` (`id`, `site_id`, `uuid`, `slug`, `page_name`, `logo_txt`, `seq`, `session_resets`, `title`, `hddr_template`, `body_template`, `footer_template`, `style`, `styles_added`, `status`, `updated`, `created`) VALUES
(1, 1, '', '', 'index.php', '<span class=\"logoT\">Tea</span><span class=\"logoM\">m</span> <span class=\"logoC\">C</span>', 0, 'env', 'TeamC', 'hddr.html', '_type01_.html', 'footer.html', 'main.css', 'env', 1, '2021-02-22 09:52:04', '2021-01-12 07:22:22'),
(2, 1, '', '', 'courseHow.php', '<span class=\"logoT\">Tea</span><span class=\"logoM\">m</span> <span class=\"logoC\">C</span>', 4, 'wayneph|try_me', 'TeamC-How', 'hddr.html', '_topic_pub_.html', 'footer.html', 'main.css', '{}', 1, '2021-02-22 10:09:51', '2021-01-12 07:22:22'),
(3, 1, '', '', 'logIn.php', '', 8, 'ccc', 'TeamC', 'hddr.html', '_login_.html', 'footer.html', 'main.css', '_login_.html', 1, '2021-02-22 10:11:02', '2021-01-22 16:09:22'),
(4, 1, '', '', 'logInValidate.php', '', 50, 'whp', 'TeamC', 'hddr.html', '_login_.html', 'footer.html', 'main.css', '_login_.html', 1, '2021-02-22 09:51:50', '2021-01-23 23:21:58'),
(5, 1, '', '', 'gaCodeRegister.php', '', 54, 'whp', 'TeamC-regGA', 'hddr.html', '_login_.html', 'footer.html', 'main.css', '_login_.html', 1, '2021-02-22 09:51:39', '2021-01-26 20:45:25'),
(6, 3, 'page-861247-641755-bb6f62-9bbddf-e7c74f-f50d26', 'hjpindex', 'index.php', '', 1, 'env|xxx|yyy.\'\'\';\';;', 'Hamish Home', 'hddr.html', '_type01_.html', 'footer.html', 'main.css', '{}', 1, '2021-07-27 18:11:29', '2021-02-20 13:55:20'),
(7, 3, 'page-c8c84e-45e6b9-a77970-480e98-a789cc-a0774f', 'hjphome', 'a page.php', '', 2, 'env|xxx|yyy.\'\'\';\';;', 'Hamish Home', 'hddr.html', '_type01_.html', 'footer.html', 'main.css', '{}', 1, '2021-07-27 18:15:54', '2021-02-20 15:57:54'),
(8, 4, 'page-283fbe-75bedd-c77e30-2757e4-3e9262-11d11f', 'cppindex', 'index.php', '', 1, 'wqertwe|1234123|asdf', 'Christian home', 'heder.html', '1.html', 'footer.html', 'style.css', '/*---------database override styles ---*/', 1, '2021-08-02 17:43:51', '2021-02-20 18:28:44'),
(9, 4, 'page-a41d6a-43b674-2a5ce2-da7c5b-13b590-51b00b', 'whatever', 'xdxd.php', '', 2, 'wqertwe|1234123|asdf', 'Christian home', 'heder.html', '1.html', 'footer.html', 'style.css', '/*---------database override styles ---*/', 1, '2021-08-02 17:45:20', '2021-02-20 18:32:58'),
(10, 5, '', '', 'Benefits4Members.php', '', 20, 'sql|envPuts|codeTrace\r\n\r\nrBenefits4Members ', 'Benefits4Members', 'r_hddr.html', 'r_body_info.html', 'r_footer.html', 'css/main.css', '{}', 1, '2021-02-28 07:45:10', '2021-02-26 13:49:09'),
(11, 5, '', '', 'index.php', '', 0, 'env', 'Math4You', 'hddr02.html', 'type02.html', 'footer02.html', 'main.css', '#header > .container {\r\n  padding: 7rem 0 0 0;\r\n  border-bottom:none; \r\n  box-shadow: none;\r\n}\r\n#header > p {\r\n    line-height:5rem;\r\n    margin-bottom: 1rem;\r\n}\r\nheader{\r\n  line-height: 3rem;\r\n}', 1, '2021-03-25 11:44:18', '2021-03-01 15:11:26'),
(12, 5, '', '', 'login.php', '', 4, 'env', 'Math4You', 'hddr.html', 'form00.html', 'footer.html', 'main.css', 'env', 1, '2021-03-13 07:51:21', '2021-03-04 21:37:57'),
(16, 5, '', '', 'register.php', '', 8, 'env', 'Math4You', 'hddr.html', 'form00.html', 'footer.html', 'main.css', 'env', 1, '2021-03-13 15:05:11', '2021-03-13 15:05:11'),
(13, 5, '', '', '_handler_.php', '', 100, 'none', 'Handler', 'none', 'none', 'none', 'none', 'none', 1, '2021-03-09 08:44:59', '2021-03-06 12:18:40'),
(14, 5, '', '', 'registerGA.php', '', 62, 'env', 'Math4You', 'hddr.html', 'form00.html', 'footer.html', 'main.css', 'env', 1, '2021-03-13 07:51:45', '2021-03-08 13:36:45'),
(15, 5, '', '', 'yourProfile.php', '', 12, 'env', 'Math4You', 'hddr.html', 'form02.html', 'footer.html', 'main.css', 'env', 1, '2021-03-13 09:04:38', '2021-03-10 14:04:59'),
(17, 6, 'page-0233d1-d8d636-2ebe4f-9136a7-d6ee4d-6e513a', 'apidocsindex', 'index.php', '', 1, 'env', 'SkunkDodocumentation', 'hddr.html', 'api00.html', 'footer.html', 'main.css', 'env', 1, '2021-07-27 12:30:05', '2021-07-27 11:15:26'),
(18, 7, 'page-e8ebbd-6353d5-d2fcab-adc601-1fbba4-f6ac0f', 'index', 'index.php', '', 80, 'NA', 'k8s DevOps', 'hddr.html', '_index_.html', 'footer.html', 'NA', '', 1, '2021-10-14 06:20:41', '2021-09-10 11:27:40'),
(19, 7, 'page-256dd2-5c2a6e-f6680d-d8b686-9ca793-1bbfc9', 'pwaInstruct', 'pwaInstruct.php', '', 51, 'NA', 'k8s DevOps', 'hddr.html', 'singleAccordion.html', 'footer.html', 'NA', '<style>\r\n  #sidebar > section\r\n  {\r\n    margin:0 0 0 0;\r\n  }\r\n  ul.divided li\r\n  {\r\n    border-top:none;\r\n    margin:0;\r\n  }\r\n  #sidebar {\r\n    padding-top: 2em;\r\n  }\r\n  #sidebar > section, #sidebar > article \r\n  {\r\n    padding:2em 0 0 0;\r\n  }\r\n</style>', 1, '2021-10-15 07:24:32', '2021-09-17 12:07:21'),
(20, 7, 'page-d7c47c-7b85ee-f16d88-85d1e0-0a89b0-3be45f', 'switch', 'switch.php', '', 52, 'na', 'k8s Switch', 'hddr.html', 'switch.html', 'footer.html', 'NA', '<style>\r\n  #copyright{\r\n    border-top:none;\r\n  }\r\n  #features, #main, #header {\r\n    padding: 2em 0;\r\n  }\r\n}\r\n</style>', 1, '2021-10-01 08:04:15', '2021-09-28 07:35:41'),
(21, 7, 'page-3a5caf-68f276-10c5ca-9b174a-5c430a-4805b1', 'showEntity', 'showEntity.php', '', 2, 'NA', 'List Entities', 'hddr.html', 'listEntities.html', 'footer.html', 'NA', '<style>\r\n  #copyright{\r\n    border-top:none;\r\n  }\r\n  #features, #main, #header {\r\n    padding: 2em 0;\r\n  }\r\n}\r\n</style>', 1, '2021-10-13 07:57:15', '2021-10-01 06:59:35'),
(22, 7, 'page-85ee2b-6adf2b-5b7c68-929071-ef67c3-4222cf', 'listEntityTypes', 'listEntityTypes.php', '', 0, 'NA', 'List Entities', 'hddr.html', 'listEntities.html', 'footer.html', 'NA', '<style>\r\n  #copyright{\r\n    border-top:none;\r\n  }\r\n  #features, #main, #header {\r\n    padding: 2em 0;\r\n  }\r\n}\r\n</style>', 1, '2021-10-13 07:47:03', '2021-10-13 07:47:03'),
(23, 7, 'page-40c2ca-e823d4-a8a1b9-2ec270-267003-8839e1', 'showEntitiesForType', 'showEntitiesForType.php', '', 1, 'NA', 'List Entities', 'hddr.html', 'listEntities.html', 'footer.html', 'NA', '<style>\r\n  #copyright{\r\n    border-top:none;\r\n  }\r\n  #features, #main, #header {\r\n    padding: 2em 0;\r\n  }\r\n}\r\n</style>', 1, '2021-10-13 08:06:58', '2021-10-13 07:55:30');
