
-- --------------------------------------------------------

--
-- Table structure for table `site_static`
--

CREATE TABLE `site_static` (
  `id` int(11) NOT NULL,
  `seq` int(11) NOT NULL,
  `site_id` int(11) NOT NULL,
  `position_name` varchar(20) NOT NULL,
  `ht` text NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `status` tinyint(4) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `site_static`
--

INSERT INTO `site_static` (`id`, `seq`, `site_id`, `position_name`, `ht`, `created`, `updated`, `status`) VALUES
(1, 1, 1, 'menuFixed', '<li><a href=\"index.php\">Home</a></li>\r\n<li><a href=\"becomeMember.php\">Why Become a Member</a></li>\r\n', '2021-01-12 08:12:58', '2021-02-28 06:18:48', 1),
(2, 5, 1, 'siteExplained', 'Teach-Math (while) Coding', '2021-01-12 08:12:58', '2021-02-22 09:15:40', 1),
(3, 8, 1, 'headerScript', '<!--noScript\r\nthis will be overwritten in scripts section if required..\r\nif not defined this is the replacement\r\n-->', '2021-01-19 16:45:51', '2021-02-23 10:02:34', 1),
(6, 0, 5, 'menuFixed', '<li>\r\n   <a href=\"index.php\">Home</a>\r\n</li>\r\n<li>\r\n   <a href=\"bebefitsMembers.php\">Member Benefits</a>\r\n</li>\r\n<li>\r\n   <a href=\"m4yPhilosophy.php\">Teaching Philosophy</a>  \r\n</li>\r\n<li>\r\n   <a href=\"m4ySylabys.php\"> Syllabus Notes </a>  \r\n</li>', '2021-02-26 14:00:47', '2021-03-09 11:56:59', 1),
(11, 1, 5, 'menuAdded-ops', '\r\n   <a href=\"login.php\" class=\"optionButton\">Login</a>\r\n\r\n|\r\n\r\n   <a href=\"logout.php\" class=\"optionButton\">Logout</a>\r\n\r\n', '2021-03-10 12:16:41', '2021-03-13 07:27:42', 1),
(9, 4, 5, 'footActions', '<footerItem>\r\n    &#128243;&nbsp;<a href=\"makeContact.php\">(+27) 81-722 8182</a>\r\n</footerItem>\r\n&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;&nbsp;\r\n<footerItem>\r\n    &#128236;&nbsp;<a href=\"makeContact.php\">info@maths4you.today</a>\r\n</footerItem>\r\n<br>', '2021-03-04 17:13:35', '2021-03-04 11:17:52', 1),
(10, 8, 5, 'copyright', '<footerItem>\r\n    &copy;&nbsp;2020-1 Content & Service by <a href=\"index.php?msg=Conceptualized, Developed and Hosted by the Foundrs.\">maths4you.today</a>\r\n</footerItem>', '2021-03-04 17:17:01', '2021-03-04 11:18:40', 1),
(14, 20, 7, 'feedback', '<form action=\"switch.php\" method=\"post\">\r\n  <input type=\"hidden\" name=\"pstSource\" value=\"<!--myName-->\">\r\n  <input type=\"hidden\" name=\"pstType\" value=\"contactForm\">\r\n  <div class=\"row gtr-50\">\r\n    <div class=\"col-6 col-12-small\">\r\n      <input name=\"pstFrom\" placeholder=\"Name\" type=\"text\" value=\"<!--personName-->\" />\r\n    </div>\r\n    <div class=\"col-6 col-12-small\">\r\n      <input name=\"pstMail\" placeholder=\"Email\" type=\"text\" value=\"<!--emailAddress-->\" />\r\n    </div>\r\n    <div class=\"col-6 col-12-small\">\r\n      <select id=\"cars\" name=\"pstCategory\">\r\n        <option value=\"none\">..Select..</option>\r\n        <option value=\"Comment\">Comment</option>\r\n        <option value=\"Question\">Question</option>\r\n        <option value=\"Response\">Response</option>\r\n        <option value=\"Request\">Request</option>\r\n        <option value=\"Suggestion\">Suggestion</option>\r\n     </select>\r\n    </div>\r\n    <div class=\"col-12\">\r\n      <textarea name=\"pstMessage\" placeholder=\"Message\"></textarea>\r\n    </div>\r\n    <div class=\"col-12\">\r\n     <input type=\"submit\" value=\"Touch Us!\">\r\n    </div>\r\n  </div>\r\n</form>\r\n', '2021-09-20 12:59:26', '2021-10-08 12:04:59', 1),
(15, 0, 7, 'siteLogo', '<h1 id=\"logo\">\r\n  <a href=\"index.php\">Kubernetes</a>\r\n</h1>\r\n<p>\r\n  for <b>DevOps</b> Professionals\r\n</p>', '2021-09-21 11:28:40', '2021-09-21 11:29:19', 1),
(16, 6, 7, 'copyRight', '<li>\r\n  &copy;contents(WaynePhilip. All rights reserved.)\r\n</li>\r\n<li>\r\n  Design: <a href=\"http://skunks.co\">SkunkWorx</a>\r\n</li>', '2021-09-21 11:36:44', '2021-09-21 11:43:29', 1),
(17, 4, 7, 'touchUs', '<h2>\r\n  Questions or comments? \r\n  <b>\r\n   Touch Us:\r\n  </b>\r\n</h2>', '2021-09-21 11:40:06', '2021-09-21 11:40:26', 1);
