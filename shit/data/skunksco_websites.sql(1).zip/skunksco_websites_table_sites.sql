
-- --------------------------------------------------------

--
-- Table structure for table `sites`
--

CREATE TABLE `sites` (
  `id` int(11) NOT NULL,
  `slug` varchar(20) NOT NULL,
  `uuid` varchar(64) NOT NULL,
  `domain_id` int(11) NOT NULL,
  `website` varchar(50) NOT NULL,
  `seq` int(11) NOT NULL,
  `status` tinyint(4) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sites`
--

INSERT INTO `sites` (`id`, `slug`, `uuid`, `domain_id`, `website`, `seq`, `status`, `created`, `updated`) VALUES
(1, 'teamc', 'pwa-d73c9e-365660-c3b032-3f4f80-cbae6c-f7e4bd', 4, 'TeamC', 1, 1, '2021-01-18 13:39:17', '2021-07-27 12:13:03'),
(7, 'k8sskunks', 'pwa-543b44-e5c6f2-f69fdd-e4f32c-da705a-2a296e', 1, 'k8s.skunks.co', 0, 1, '2021-09-10 11:26:20', '2021-09-10 11:27:12'),
(3, 'hjp', 'pwa-5ed9ef-ddab9d-e0191a-cec620-2c3a7c-d5a6d3', 1, 'HamishJohnPhilip', 1, 1, '2021-02-03 18:38:19', '2021-07-27 12:12:39'),
(4, 'cpp', 'pwa-23be17-0e2d62-425253-e018d8-015f6e-13c2f4', 2, 'ChristianPeterPhilip', 1, 1, '2021-02-20 16:47:29', '2021-07-27 12:12:22'),
(5, 'm4u', 'pwa-720f39-12fed7-33e6e5-eb27af-2ba2de-bac258', 2, 'math4You', 1, 1, '2021-02-26 13:43:12', '2021-07-27 12:12:10'),
(6, 'apidocs', 'pwa-d9ee79-55620a-f2eaeb-92e12a-d0f2e1-f9100b', 1, 'APIdocs', 1, 1, '2021-04-26 07:13:59', '2021-07-27 12:11:18'),
(8, 'k8sskunks', 'pwa-543b44-e5c6f2-f69fdd-e4f32c-da705a-2a296e', 1, 'tsc.skunks.co', 0, 1, '2021-10-17 10:35:44', '2021-10-17 10:35:44');
